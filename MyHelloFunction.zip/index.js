var AWS = require('aws-sdk');
var ssm = new AWS.SSM({apiVersion: '2014-11-06'});
var sns = new AWS.SNS({apiVersion: '2010-03-31'});

exports.handler = (event, context, callback) => {
    // TODO implement
    callback(null, 'Hello from Lambda');
    // Log the event that was received
    console.log("Event was ", JSON.stringify(event));
    
    var eventbody = event["body-json"];
    
    console.log("Web Page Text is  ", eventbody);
    
    var webpagetext = '"'+eventbody["WebPageHeadLine"]+'"';
    console.log("Web Page Text is  ", webpagetext);
    //Get Instance ID from Env variable
    var webserverid = process.env.instnaceid;
    var psscriptlocation = process.env.scriptlocation;
    // Use SSM to send the command to server for updating
    
    // Send the actual SNS Message
    // sns.publish(params, function(err, data) {
    //   if (err) console.log(err, err.stack); // an error occurred
    //   else     console.log(data);           // successful response
    // });
    
    var ssmparams = {
    DocumentName: 'AWS-RunPowerShellScript',
    Comment: 'Running client creation script from Lambda',
    InstanceIds: [
        webserverid
    ],
    Parameters: {
        'commands': [
            psscriptlocation+' '+webpagetext
            ]
        },
    };

    ssm.sendCommand(ssmparams, function(err, data){
        if (err) {
            console.log(err, err.stack);
            callback('Error was', err);
        }
        else {
            console.log(data);
        
        }
    });
    
    
};
